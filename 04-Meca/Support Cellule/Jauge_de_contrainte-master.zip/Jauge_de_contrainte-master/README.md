# Jauge_de_contrainte
Mesure poids avec jauge de contrainte et carte Arduino . 
Le dossier contient ;
Le programme pour Arduino UNO . ( 
Le schéma et le circuit imprimé conçu sous proteus 8 .( Balance_INA128.pdsprj )
Le schéma electronique en BMP. ( Balance_INA128.BMP )
