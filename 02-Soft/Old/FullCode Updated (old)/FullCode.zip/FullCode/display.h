
#ifndef _DISPLAY_H
#define _DISPLAY_H

#include "SevSeg.h"

#ifdef __cplusplus
extern "C" {
#endif


void SevSegSetup(void);


#endif /* _DISPLAY_H */

#ifdef __cplusplus
}
#endif
